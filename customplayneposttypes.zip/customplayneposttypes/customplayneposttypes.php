<?php

/*
 Plugin Name: Custom Playne Post Types
 Plugin URI: http://themeforest.net/user/playnethemes
 Description: Custom post types for use in the Knowy theme.
 Author: Playne Themes
 Author URI: http://themeforest.net/user/playnethemes
 Version: 1.0
 */

/*-----------------------------------------------------------------------------------*/

/*	Knowledge post type

/*-----------------------------------------------------------------------------------*/

function playne_knowledge_custom_init() {

	$playne_knowledge_labels = array(
		'name' => _x('Articles', 'post type general name', 'playne'),
		'singular_name' => _x('Article', 'post type singular name', 'playne'),
		'add_new' => _x('Add New', 'Article', 'playne'),
		'add_new_item' => __('Add New Article', 'playne'),
		'edit_item' => __('Edit Article', 'playne'),
		'new_item' => __('New Article', 'playne'),
		'view_item' => __('View Article', 'playne'),
		'search_items' => __('Search Articles', 'playne'),
		'not_found' =>  __('No Articles found', 'playne'),
		'not_found_in_trash' => __('No Articles found in Trash', 'playne'),
		'parent_item_colon' => '',
		'menu_name' => 'Articles'
	);

	$playne_knowledge_args = array(
		'menu_icon' => 'dashicons-format-aside',
		'labels' => $playne_knowledge_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'has_archive' => true,
		'hierarchical' => false,
		'taxonomies' => array('post_tag'),
		'menu_position' => null,
		'supports' => array('title','editor','author','thumbnail','page-attributes','excerpt')
	);
	
	register_post_type('kb',$playne_knowledge_args);

	$playne_knowledge_category_labels = array(
		'name' => _x( 'Categories', 'taxonomy general name', 'playne' ),
		'singular_name' => _x( 'Category', 'taxonomy singular name', 'playne' ),
		'search_items' =>  __( 'Search Articles', 'playne' ),
		'all_items' => __( 'All Categories', 'playne' ),
		'parent_item' => __( 'Parent Category', 'playne' ),
		'parent_item_colon' => __( 'Parent Category:', 'playne' ),
		'edit_item' => __( 'Edit Categoriess', 'playne' ),
		'update_item' => __( 'Update Category', 'playne' ),
		'add_new_item' => __( 'Add New Category', 'playne' ),
		'new_item_name' => __( 'New Category Name', 'playne' ),
	);

	register_taxonomy('section',array('kb'), array(
		'hierarchical' => true,
		'labels' => $playne_knowledge_category_labels,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'section' ),
	));

}
add_action('init', 'playne_knowledge_custom_init');

function playne_knowledge_updated_messages( $playne_knowledge_messages ) {

	  	global $post, $post_ID;

	  	$playne_knowledge_messages['kb'] = array(

			1 => sprintf( __('Article updated. <a href="%s">View</a>'), esc_url( get_permalink($post_ID) ) ),
			2 => __('Custom field updated.', 'playne'),
			3 => __('Custom field deleted.', 'playne'),
			4 => __('Article updated.', 'playne'),
			5 => isset($_GET['revision']) ? sprintf( __('Article restored to revision from %s', 'playne'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
			6 => sprintf( __('Article published. <a href="%s">View</a>'), esc_url( get_permalink($post_ID) ) ),
			7 => __('Article saved.', 'playne'),
			8 => sprintf( __('Article submitted. <a target="_blank" href="%s">Preview</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
			9 => sprintf( __('Article scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview</a>'),
			  date_i18n( __( 'M j, Y @ G:i', 'playne'), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
			10 => sprintf( __('Article draft updated. <a target="_blank" href="%s">Preview</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
		  
	  	);

	  return $playne_knowledge_messages;
}
add_filter('post_updated_messages', 'playne_knowledge_updated_messages');

/*-----------------------------------------------------------------------------------*/

/*	FAQ post type

/*-----------------------------------------------------------------------------------*/

function playne_faq_custom_init() {

	$playne_faq_labels = array(
		'name' => _x('FAQs', 'post type general name', 'playne'),
		'singular_name' => _x('FAQ', 'post type singular name', 'playne'),
		'add_new' => _x('Add New', 'FAQ', 'playne'),
		'add_new_item' => __('Add New FAQ', 'playne'),
		'edit_item' => __('Edit FAQ', 'playne'),
		'new_item' => __('New FAQ', 'playne'),
		'view_item' => __('View FAQ', 'playne'),
		'search_items' => __('Search FAQs', 'playne'),
		'not_found' =>  __('No FAQs found', 'playne'),
		'not_found_in_trash' => __('No FAQs found in Trash', 'playne'),
		'parent_item_colon' => '',
		'menu_name' => 'FAQ'
	);

	$playne_faq_args = array(
		'menu_icon' => 'dashicons-editor-help',
		'labels' => $playne_faq_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'has_archive' => true,
		'hierarchical' => false,
		'taxonomies' => array('post_tag'),
		'menu_position' => null,
		'supports' => array('title','editor','author','thumbnail','page-attributes', 'post-formats')
	);

	register_post_type('faq',$playne_faq_args);

	$playne_faq_cat_labels = array(
		'name' => _x( 'Categories', 'taxonomy general name', 'playne' ),
		'singular_name' => _x( 'Category', 'taxonomy singular name', 'playne' ),
		'search_items' =>  __( 'Search Types', 'playne' ),
		'all_items' => __( 'All Categories', 'playne' ),
		'parent_item' => __( 'Parent Category', 'playne' ),
		'parent_item_colon' => __( 'Parent Category:', 'playne' ),
		'edit_item' => __( 'Edit Categoriess', 'playne' ),
		'update_item' => __( 'Update Category', 'playne' ),
		'add_new_item' => __( 'Add New Category', 'playne' ),
		'new_item_name' => __( 'New Category Name', 'playne' ),
	);

	register_taxonomy('faq_cat',array('faq'), array(
		'hierarchical' => true,
		'labels' => $playne_faq_cat_labels,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'faqcat' ),
	));

}
add_action('init', 'playne_faq_custom_init');

function playne_faqs_updated_messages( $playne_faq_messages ) {
	 
	global $post, $post_ID;
	
	$playne_faq_messages['faqs'] = array(
		1 => sprintf( __('FAQ updated. <a href="%s">View</a>'), esc_url( get_permalink($post_ID) ) ),
		2 => __('Custom field updated.', 'playne'),
		3 => __('Custom field deleted.', 'playne'),
		4 => __('FAQ updated.', 'playne'),
		5 => isset($_GET['revision']) ? sprintf( __('FAQ restored to revision from %s', 'playne'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6 => sprintf( __('FAQ published. <a href="%s">View</a>'), esc_url( get_permalink($post_ID) ) ),
		7 => __('FAQ saved.', 'playne'),
		8 => sprintf( __('FAQ submitted. <a target="_blank" href="%s">Preview</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
		9 => sprintf( __('FAQ scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview</a>'),
		  date_i18n( __( 'M j, Y @ G:i', 'playne'), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
		10 => sprintf( __('FAQ draft updated. <a target="_blank" href="%s">Preview</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
	
	);
	return $playne_faq_messages;
}
add_filter('post_updated_messages', 'playne_faqs_updated_messages');

?>